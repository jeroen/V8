#VERSION=v8.17.0
VERSION=v10.24.1
PATH=/opt/csw/bin:$PATH
export CC="gcc"
export CXX="g++"
curl -OL "https://nodejs.org/download/release/${VERSION}/node-${VERSION}.tar.gz"
gunzip node-${VERSION}.tar.gz
rm -Rf node-${VERSION}
gtar xf node-${VERSION}.tar
cd node-${VERSION}
gsed -i.bak 's/V8_LIBC_BIONIC/1/g' deps/v8/src/allocation.cc
gsed -i.bak 's/V8_OS_SOLARIS/V8_OS_BLA/g' deps/v8/src/base/debug/stack_trace_posix.cc
gsed -i.bak 's/-O3/-O2/g' common.gypi
./configure --shared --without-ssl --without-npm --without-dtrace --without-inspector --without-intl 
gmake 

# Copy files
mkdir -p ../v8-static/lib
cp out/Release/*.a ../v8-static/lib
cp -r deps/v8/include ../v8-static/


